/*
 * ADC.h
 *
 * Created: 12.10.2013 18:28:11
 *  Author: Ole
 */ 


#ifndef ADC_H_
#define ADC_H_

void adc_init();
void leds_and_buttons_init();


#endif /* ADC_H_ */