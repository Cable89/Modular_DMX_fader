/*
 * general.h
 *
 * Created: 28.02.2015 14:51:40
 *  Author: Ole
 */ 


#ifndef GENERAL_H_
#define GENERAL_H_

//#define MASTER
#define SLAVE



#endif /* GENERAL_H_ */